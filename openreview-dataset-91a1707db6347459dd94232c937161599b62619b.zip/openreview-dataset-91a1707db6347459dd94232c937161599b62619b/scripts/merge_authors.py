import json

import jsons

with open("authors.json", "r") as f:
    data = json.load(f)

class Author:
    """Represents one author: contains all their known aliases and emails."""
    def __init__(self, aliases : set, emails : set):
        self.aliases = set(aliases)
        self.emails = set(emails)

    def __eq__(self, other):
        return self.aliases & other.aliases or self.emails & other.emails

    def merge(self, other):
        self.aliases = self.aliases | other.aliases
        self.emails = self.emails | other.emails

result = list()

def insert(a):
    for item in result:
        if a == item:
            item.merge(a)
            return
    result.append(a)


for d in data:
    name = set([d["name"]]) if d["name"] else set()
    email = set([d["email"]]) if d["email"] else set()
    a = Author(name, email)
    insert(a)


with open("authors-temp.json", "w") as f:
    j = jsons.dump(result)
    json.dump(j, f, indent=4, ensure_ascii=False)

