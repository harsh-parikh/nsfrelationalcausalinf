#!/usr/bin/env python3
import json
from time import sleep

import openreview
import progressbar
from joblib import Parallel, delayed

c = openreview.Client(baseurl='https://openreview.net')

def get_paper_info(forum_id):
    sleep(0.06)
    try:
        notes = c.get_notes(forum=forum_id)
    except:
        notes = c.get_notes(forum=forum_id)
    for n in filter(lambda n: n.id == forum_id, notes):
        try:
            return {**n.content, "conf": n.invitation}
        except (AttributeError, KeyError):
            pass
    return {}

def final_paper(forum_id, decision):
    return {**get_paper_info(forum_id), "decision": decision,
            "paper_id": forum_id}

with open("decisions.json", "r") as f:
    data = json.load(f)

data = progressbar.progressbar(data)

paper_details = Parallel(n_jobs=8)(delayed(final_paper)(f_id,d) for f_id, d in data)
paper_details = list(filter(lambda p: "conf" in p,paper_details))

with open("papers-temp.json", "w", encoding="utf-8") as f:
    json.dump(paper_details, f, ensure_ascii=False, indent=4)
