#!/usr/bin/env python3
import json

import openreview

c = openreview.Client(baseurl='https://openreview.net')

batch = 100
offset = 0
result = []
ingest = c.search_notes("'decision':", source="replies", offset=offset, limit=batch)
result += ingest
while len(ingest) == 100:
    print(f"ingested {offset} records")
    ingest = c.search_notes("'decision':",source="replies", offset=offset, limit=batch)
    result += ingest
    offset += batch

def forum_to_name(f_id):
    notes = c.get_notes(forum="HJqk3N1vG")
    for n in notes:
        try:
            if n.details
        except AttributeError:
            pass


result_decisions = [(x.forum, x.content["decision"]) for x in filter(lambda y: 'decision' in y.content, result)]

with open("decisions.json", "w", encoding="utf-8") as f:
    json.dump(result_decisions, f, ensure_ascii=False, indent=4)


