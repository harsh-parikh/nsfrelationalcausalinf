import json
from itertools import zip_longest
from collections import defaultdict

with open("papers.json", "r") as f:
    data = json.load(f)

def custom_zip(paper):
    try:
        p = defaultdict(list, paper['paper_info'])
        return list(zip_longest(p['authors'],
                           p['authorids']))
    except TypeError:
        return []


authors = set()
for p in data:
    authors.update(custom_zip(p))

def quantify(iterable, pred=bool):
    "Count how many times the predicate is true"
    return sum(map(pred, iterable))

missing = quantify(authors, lambda p: not(p[0] and p[1])) / len(authors)

print(f"{missing * 100:.1f}% missing name or email")

authors = map(lambda a: {"id": a[0], "name": a[1][0], "email": a[1][1]},
              enumerate(authors))

with open("authors-temp.json", "w") as f:
    json.dump(list(authors), f, indent=4, ensure_ascii=False)
