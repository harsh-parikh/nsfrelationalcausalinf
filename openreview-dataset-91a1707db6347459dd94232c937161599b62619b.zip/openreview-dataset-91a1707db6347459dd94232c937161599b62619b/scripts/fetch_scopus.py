#!/usr/bin/env python
import json
import pprint
import signal

import pybliometrics
from pybliometrics.scopus.exception import Scopus429Error, ScopusQueryError, Scopus400Error
from requests.exceptions import ConnectionError
from progressbar import progressbar

print = pprint.pprint
table = str.maketrans(dict.fromkeys('*'))

def handler(signum, frame):
    raise TimeoutError("scopus request timeout")

with open("authors-temp.json", "r") as f:
    data = json.load(f)

for a in progressbar(data):
    try:
        if "scopus" in a or not a["name"]:
            continue

        name = a["name"].translate(table).split(" ")
        last = name[-1]
        first = " ".join(name[:-1])
        if not (first and last):
            a["scopus"] = None
            continue

        signal.signal(signal.SIGALRM, handler)
        #signal.alarm(10)
        try:
            query = f"authlast({last}) and authfirst({first})"
            reply = pybliometrics.scopus.AuthorSearch(query, count=1, download=True, max_entries=1e6, subscriber=True)
        except (TimeoutError, ConnectionError):
            continue
        except (Scopus400Error):
            print(f"invalid query: {query}")
            continue
        #signal.alarm(0)
      
        if not reply.get_results_size() or not reply.authors[0].eid:
            a["scopus"] = None
            continue
        id = reply.authors[0].eid

        result = pybliometrics.scopus.AuthorRetrieval(id)
        a["scopus"] = result.__dict__
    except Scopus429Error:
        # our API key is exhausted; write what we have to disk
        print("[!] please rotate API key")
        break

with open("authors-temp.json", "w") as f:
    json.dump(data, f, ensure_ascii=False, indent=4)
 
