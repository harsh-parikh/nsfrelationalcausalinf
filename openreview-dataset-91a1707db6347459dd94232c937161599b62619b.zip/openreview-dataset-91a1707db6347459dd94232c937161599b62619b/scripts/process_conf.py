#!/usr/bin/env python3

import json

with open("results/papers.json", "r") as f:
    papers = json.load(f)

conf = {}

for p in papers:
    if p["conf"] not in conf:
        conf[p["conf"]] = {}
        conf[p["conf"]]["accept"] = 0
        conf[p["conf"]]["reject"] = 0

    x = conf[p["conf"]]
    if "reject" in p["decision"].lower():
        x["reject"] += 1
    else:
        x["accept"] += 1

for c in conf.values():
    c["rigor"] = c["reject"] / (c["reject"] + c["accept"])

with open("conf-temp.json", "w") as f:
     json.dump(conf, f, ensure_ascii=False, indent=4)

