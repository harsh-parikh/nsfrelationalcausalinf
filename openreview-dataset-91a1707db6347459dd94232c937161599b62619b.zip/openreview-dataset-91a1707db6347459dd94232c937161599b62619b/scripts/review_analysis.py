#!/usr/bin/env python

import json

with open("results/reviews.json", "r") as f:
    data = json.load(f)

hashes = [len(data[d]) for d in data]
print(sum(hashes) / len(hashes))

for d in data:
    data[d] = list(filter(lambda r: "confidence" in r and "rating" in r, data[d]))

conf_mappings = {
     # lowest rating is shared between all systems of rating
     "1: The reviewer's evaluation is an educated guess": 0/2,
     # first system of rating
     '2: The reviewer is fairly confident that the evaluation is correct': 1/2,
     '3: The reviewer is absolutely certain that the evaluation is correct and very familiar with the relevant literature': 2/2,
     # second system of rating
     '2: The reviewer is willing to defend the evaluation, but it is quite likely that the reviewer did not understand central parts of the paper': 1/4,
     '3: The reviewer is fairly confident that the evaluation is correct': 2/4,
     '4: The reviewer is confident but not absolutely certain that the evaluation is correct': 3/4,
     '5: The reviewer is absolutely certain that the evaluation is correct and very familiar with the relevant literature': 4/4,
}

rating_mappings = {
     # out of 5
    '1: Trivial or wrong': 0/4,
    '1: Strong Reject': 0/4,
    '2: Weak Reject': 1/4,
    '2: Reject':1/4,
    '2: Marginally below acceptance threshold': 2/5,
    '3: Accept': 3/5,
    '3: Borderline': 1/2,
    '3: Marginally above acceptance threshold': 3/5,
    '4: Top 50% of accepted papers, clear accept': 4/5,
    '4: Strong accept': 4/5,
    '5: Top 15% of accepted papers, strong accept': 5/5,
    '5: Strong Accept': 5/5,
     # out of 10
    '1: Strong rejection': 0/9,
    '1: Strong reject': 0/9,
    '2: Strong rejection': 1/9,
    '3: Clear rejection': 2/9,
    '4: Weak Accept': 5/9,
    '4: Ok but not good enough - rejection': 3/9,
    '5: Marginally below acceptance threshold': 4/9,
    '6: Marginally above acceptance threshold': 5/9,
    '7: Good paper, accept': 6/9,
    '8: Top 50% of accepted papers, clear accept': 7/9,
    '9: Top 15% of accepted papers, strong accept': 8/9,
    '10: Top 5% of accepted papers, seminal paper': 9/9,
}

for p_id in data:
    for r in data[p_id]:
        r["norm_conf"] = conf_mappings[r["confidence"]]
        r["norm_rating"] = rating_mappings[r["rating"]]

hashes = [len(data[d]) for d in data]
print(sum(hashes) / len(hashes))

with open("review-temp.json", "w") as f:
    json.dump(data, f, ensure_ascii=False, indent=2)
