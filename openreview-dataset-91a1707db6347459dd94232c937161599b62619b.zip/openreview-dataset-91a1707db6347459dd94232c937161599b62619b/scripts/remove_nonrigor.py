#!/bin/usr/env python3

import json

with open("results/papers.json", "r") as f:
    papers = json.load(f)


with open("results/confs.json", "r") as f:
    confs = json.load(f)

print(f"read {len(papers)} papers")
papers = list(filter(lambda p: confs[p["conf"]]["rigor"], papers))
print(f"{len(papers)} papers remain")

with open("papers-temp.json", "w") as f:
    json.dump(papers, f, ensure_ascii=False, indent=4)

