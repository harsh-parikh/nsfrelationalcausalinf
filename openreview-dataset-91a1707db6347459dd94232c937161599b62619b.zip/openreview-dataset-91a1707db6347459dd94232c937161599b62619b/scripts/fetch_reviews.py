#!/usr/bin/env python

import json
from random import uniform
from collections import defaultdict
import itertools

import openreview
from progressbar import progressbar
from joblib import Parallel, delayed, parallel_backend

def note_to_dict(n):
    try:
        return {**n.content,
                "review_of": n.replyto}
    except:
        pass

def get_reviews(f_id):
    try:
        comments = c.get_notes(forum=f_id)
    except:
        try:
            comments = c.get_notes(forum=f_id)
        except:
            print(f"skipping: {f_id}")
            return
    rs = filter(lambda r: "review" in r.content, comments)
    return [note_to_dict(r) for r in rs]


c = openreview.Client(baseurl='https://openreview.net')

with open("decisions.json", "r") as f:
    data = json.load(f)

data = progressbar(data)
reviews = Parallel(n_jobs=8)(delayed(get_reviews)(d[0]) for d in data)
reviews = list(itertools.chain.from_iterable(reviews))

result = defaultdict(list)
for r in reviews:
    result[r["review_of"]].append(r)

with open("reviews-temp.json", "w") as f:
    json.dump(result, f, indent=4, ensure_ascii=False)
