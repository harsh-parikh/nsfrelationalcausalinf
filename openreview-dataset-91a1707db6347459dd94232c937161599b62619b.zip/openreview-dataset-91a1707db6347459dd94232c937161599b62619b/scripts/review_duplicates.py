import json
from frozendict import frozendict

with open("reviews.json", "r") as f:
    data = json.load(f)

data = [{**d["content"], **{"paperhash": d["paperhash"]}} for d in data]
data = {frozendict(d) for d in data}
data = [dict(d) for d in data]

with open("reviews-temp.json", "w") as f:
    json.dump(data, f, indent=4, ensure_ascii=False)
