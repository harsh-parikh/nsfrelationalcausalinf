OpenReview Dataset
====

This is a dataset of peer review in 13 computer science conferences. It includes ~3000 submitted papers, both accepted and rejected.

The data is under `results/`, while the scripts used to fetch and process the data are under `scripts/`. Dependencies for running those scripts can be fetched with the tool `poetry` found [here](https://poetry.eustace.io).

